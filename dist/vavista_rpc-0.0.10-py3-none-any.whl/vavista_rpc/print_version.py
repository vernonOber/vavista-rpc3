if __name__ == '__main__':
    version = '0.0.10'
    print('Version: %s' % version)
